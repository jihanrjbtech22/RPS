import os
import cv2
import mediapipe as mp
import random
import numpy as np
import joblib
import sys

def detect_hand_landmarks(image_path):
    landmarks = []
    image = cv2.imread(image_path)
    if image is None:
        print(f"Could not read the image: {image_path}")
        return landmarks

    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.6)

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    results = hands.process(image_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            for landmark in hand_landmarks.landmark:
                x = landmark.x
                y = landmark.y
                landmarks.append((x, y))
    return landmarks


def create_dataset(dataset_dir):
    dataset = []
    labels = []

    for class_name in os.listdir(dataset_dir):
        class_dir = os.path.join(dataset_dir, class_name)

        if os.path.isdir(class_dir):
            for img_file in os.listdir(class_dir):
                img_path = os.path.join(class_dir, img_file)

                landmarks = detect_hand_landmarks(img_path)
                if landmarks:
                    dataset.append(landmarks)
                    labels.append(class_name)
                else:
                    print(f"No landmarks detected for image: {img_path}")

    combined_data = list(zip(dataset, labels))
    random.shuffle(combined_data)
    dataset, labels = zip(*combined_data)

    print("Extracted Dataset Size: ", len(dataset))

    return dataset, labels


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script_name.py dataset_directory_path")
        sys.exit(1)

    dataset_dir = sys.argv[1]
    output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Datasetpkl")
    output_file = os.path.join(output_dir, dataset_dir.split('/')[-1]+".pkl")

    dataset, labels = create_dataset(dataset_dir)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    joblib.dump((np.array(dataset), np.array(labels)), output_file)
    print(f"Dataset saved as {output_file}")
