import os
import numpy as np
import joblib
from sklearn.metrics import precision_score, recall_score
import sys

def calculate_precision_recall(dataset_file, model):
    # Load the dataset from the pickle file
    dataset, true_labels = joblib.load(dataset_file)

    # Reshape the dataset if it has three dimensions
    if dataset.ndim == 3:
        dataset = dataset.reshape(dataset.shape[0], -1)

    # Make predictions using the model
    predicted_labels = model.predict(dataset)

    # Calculate precision and recall
    precision = precision_score(true_labels, predicted_labels, average='macro')
    recall = recall_score(true_labels, predicted_labels, average='macro')

    return precision, recall


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python script.py <dataset_file.pkl> <model_file.pkl>")
        sys.exit(1)

    dataset_file = sys.argv[1]
    model_file = sys.argv[2]

    if not os.path.exists(dataset_file):
        print("Dataset file does not exist.")
        sys.exit(1)

    if not os.path.exists(model_file):
        print("Model file does not exist.")
        sys.exit(1)

    # Load the trained model
    clf = joblib.load(model_file)

    # Calculate precision and recall
    precision, recall = calculate_precision_recall(dataset_file, clf)

    print("Precision:", precision)
    print("Recall:", recall)
