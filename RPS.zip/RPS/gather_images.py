import cv2 
import os
import sys

try:
    label_name = sys.argv[1]
    num_samples = int(sys.argv[2])
except:
    print("Arguments missing.")
    exit(-1)

IMG_SAVE_PATH = '../datasets/image_data_test'
IMG_CLASS_PATH = os.path.join(IMG_SAVE_PATH, label_name)

try:
    os.makedirs(IMG_SAVE_PATH, exist_ok=True)
    os.makedirs(IMG_CLASS_PATH, exist_ok=True)
except OSError as e:
    print("Error creating directories:", e)
    exit(-1)

cap = cv2.VideoCapture(0)

start = False
count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    if count == num_samples:
        break

    frame_height, frame_width = frame.shape[:2]
    roi_size = 400
    roi_start_x = (frame_width - roi_size) // 2
    roi_start_y = (frame_height - roi_size) // 2
    roi_end_x = roi_start_x + roi_size
    roi_end_y = roi_start_y + roi_size

    cv2.rectangle(frame, (roi_start_x, roi_start_y), (roi_end_x, roi_end_y), (255, 255, 255), 2)

    if start:
        roi = frame[roi_start_y:roi_end_y, roi_start_x:roi_end_x]
        save_path = os.path.join(IMG_CLASS_PATH, '{}.jpg'.format(count + 1))
        cv2.imwrite(save_path, roi)
        count += 1

    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(frame, "Collecting {}".format(count),
                (5, 50), font, 0.7, (0, 255, 255), 2, cv2.LINE_AA)
    cv2.imshow("Collecting images", frame)

    k = cv2.waitKey(10)
    if k == ord('a'):
        start = not start

    if k == ord('q'):
        break

print("\n{} image(s) saved to {}".format(count, IMG_CLASS_PATH))
cap.release()
cv2.destroyAllWindows()