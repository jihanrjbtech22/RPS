import cv2
import mediapipe as mp

def draw_hand_outline(frame, hand_landmarks):
    # Define the connections between landmarks to form the hand outline
    connections = [[0, 1], [1, 2], [2, 3], [3, 4], [5, 6], [6, 7], [7, 8], [9, 10], [10, 11],
                   [11, 12], [13, 14], [14, 15], [15, 16], [17, 18], [18, 19], [19, 20]]

    # Draw lines between landmarks to form the hand outline
    for connection in connections:
        start_point = (int(hand_landmarks.landmark[connection[0]].x * frame.shape[1]),
                       int(hand_landmarks.landmark[connection[0]].y * frame.shape[0]))
        end_point = (int(hand_landmarks.landmark[connection[1]].x * frame.shape[1]),
                     int(hand_landmarks.landmark[connection[1]].y * frame.shape[0]))
        cv2.line(frame, start_point, end_point, (255, 0, 0), 2)

def detect_hand_landmarks_live():
    # Initialize MediaPipe Hands model
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(static_image_mode=False, max_num_hands=5)

    # Open a video capture device (webcam)
    cap = cv2.VideoCapture(0)

    while cap.isOpened():
        # Read a frame from the webcam
        ret, frame = cap.read()
        if not ret:
            break

        # Convert the frame to RGB
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Process the frame and get hand landmarks
        results = hands.process(frame_rgb)

        # If landmarks are detected
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw landmarks
                for landmark in hand_landmarks.landmark:
                    x = int(landmark.x * frame.shape[1])
                    y = int(landmark.y * frame.shape[0])
                    cv2.circle(frame, (x, y), 5, (0, 255, 0), -1)
                # Draw hand outline
                draw_hand_outline(frame, hand_landmarks)

        # Display the frame with landmarks
        cv2.imshow("Hand Landmarks", frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the video capture device and close all windows
    cap.release()
    cv2.destroyAllWindows()

# Call the function to detect hand landmarks in live feed
detect_hand_landmarks_live()
