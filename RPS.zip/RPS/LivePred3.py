import cv2
import os
import sys
import numpy as np
import joblib
import mediapipe as mp

desc = '''Script to make live predictions using a trained model on images captured in real-time.

Usage: python live_prediction.py <model_path>

The script will load the trained model and use it to predict the labels of images captured from the webcam in real-time.

Press 'a' to start/pause capturing images for prediction.
Press 'q' to quit.

'''

try:
    model_path = sys.argv[1]
except:
    print("Model path missing.")
    print(desc)
    exit(-1)

if not os.path.exists(model_path):
    print("Model path does not exist.")
    exit(-1)

clf = joblib.load(model_path)

IMG_SAVE_PATH = 'live_prediction_data'

try:
    os.mkdir(IMG_SAVE_PATH)
except FileExistsError:
    pass

cap = cv2.VideoCapture(0)

start = False

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.4,
    min_tracking_confidence=0.5,
)

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    cv2.putText(frame, "Press 'a' to start/pause capturing images for prediction", (5, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
    cv2.putText(frame, "Press 'q' to quit", (5, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)

    cv2.imshow("Live Prediction", frame)

    k = cv2.waitKey(10)
    if k == ord('a'):
        start = not start
        if start:
            print("Live prediction started.")
        else:
            print("Live prediction paused.")

    if k == ord('q'):
        break

    if start:
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        results = hands.process(frame_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                for landmark in hand_landmarks.landmark:
                    x = int(landmark.x * frame.shape[1])
                    y = int(landmark.y * frame.shape[0])
                    cv2.circle(frame, (x, y), 5, (0, 255, 0), -1)

            landmarks = []
            for hand_landmarks in results.multi_hand_landmarks:
                for landmark in hand_landmarks.landmark:
                    x = landmark.x
                    y = landmark.y
                    landmarks.append(x)
                    landmarks.append(y)

            prediction = clf.predict([landmarks])[0]
            print("Prediction:", prediction)
            cv2.putText(frame, prediction, (frame.shape[1] - 200, 70),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

    cv2.imshow("Live Prediction", frame)

print("Live prediction stopped.")
cap.release()
cv2.destroyAllWindows()
