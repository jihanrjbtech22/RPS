import os
import sys
import joblib
import numpy as np
from random import shuffle

def combine_datasets(folder_path):

    all_datasets = []
    all_labels = []

    for filename in os.listdir(folder_path):
        if filename.endswith(".pkl"):
            #Load dataset points and labels from each pickle file
            dataset, labels = joblib.load(os.path.join(folder_path, filename))
            all_datasets.append(dataset)
            all_labels.append(labels)

    combined_data = list(zip(all_datasets, all_labels))


    shuffle(combined_data)



    combined_datasets, combined_labels = zip(*combined_data)

    combined_dataset = np.concatenate(combined_datasets)
    combined_labels = np.concatenate(combined_labels)

    joblib.dump((combined_dataset, combined_labels), "combine_dataset.pkl")
    print("Combined Size: ", len(combined_dataset))
    print("Dataset combined and shuffled")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <folder_path>")
        sys.exit(1)

    folder_path = sys.argv[1]

    if not os.path.exists(folder_path):
        print("Folder does not exist.")
        sys.exit(1)

    combine_datasets(folder_path)
