import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

dataset_path = "combined_dataset.pkl"  # Replace "your_dataset.pkl" with the path to your .pkl file
#print("Combined size: ", )
dataset, labels = joblib.load(dataset_path)
print("Combined size: ", len(dataset))
X =np.array(dataset)
y = np.array(labels)

X_train,X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

#Reshape the dataset for training
X_train_flat =X_train.reshape(X_train.shape[0],m-1)
X_test_flat= X_test.reshape(X_test.shape[0], -1)


clf = RandomForestClassifier(n_estimators=1)
clf.fit(X_train_flat, y_train)

y_pred = clf.predict(X_test_flat)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

model_name = "RF_model_combined.pkl"
joblib.dump(clf, model_name)
print(f"Model saved as {model_name}")
